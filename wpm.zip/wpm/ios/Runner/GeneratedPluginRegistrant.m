//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_local_notifications/FlutterLocalNotificationsPlugin.h>)
#import <flutter_local_notifications/FlutterLocalNotificationsPlugin.h>
#else
@import flutter_local_notifications;
#endif

#if __has_include(<is_lock_screen/IsLockScreenPlugin.h>)
#import <is_lock_screen/IsLockScreenPlugin.h>
#else
@import is_lock_screen;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterLocalNotificationsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterLocalNotificationsPlugin"]];
  [IsLockScreenPlugin registerWithRegistrar:[registry registrarForPlugin:@"IsLockScreenPlugin"]];
}

@end
